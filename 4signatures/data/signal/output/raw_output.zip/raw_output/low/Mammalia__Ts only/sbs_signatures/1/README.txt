10.10.2024, 22:05:00
Threshold p-value: 0.05
Threshold percentage: 5

Note: contributions.csv contains point estimate (median) solution and may contain organ-specific signatures. reference_contributions.csv will convert any organ-specific contributions to the equivalent reference signature contributions. If no organ-specific cancer signatures were used in the fit then these files should look the same.