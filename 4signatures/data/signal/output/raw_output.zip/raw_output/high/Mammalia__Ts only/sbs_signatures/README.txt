Signature fitting can be performed multiple times with different parameters. Each directory contains one such solution, numbered according to the order in which the analyses were submitted.
